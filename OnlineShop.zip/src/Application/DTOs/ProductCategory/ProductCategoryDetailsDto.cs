﻿namespace OnlineShop.Application.DTOs.ProductCategory
{
    public class ProductCategoryDetailsDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int? MahakId { get; set; }
        public long? MahakClientId { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
