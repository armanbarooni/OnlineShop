﻿namespace OnlineShop.Domain;

public class Class1
{

}
